package com.hsbc.payrolldatabaseImplementation;

public class PayrollDatabaseImplementation {

}
