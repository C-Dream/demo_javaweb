package com.hsbc.transactionapplication;

public class TransactionSource {

}
