package com.hsbc.transactionImplementation;

import com.hsbc.abstracttransactions.ChangeMethodTransaction;
import com.hsbc.payrolldatabase.PayrollDatabase;
import com.hsbc.payrolldomain.PaymentMethod;
import com.hsbc.payrollimplementation.MailMethod;

public class ChangeMailTransaction extends ChangeMethodTransaction {
	private final String address;

	public ChangeMailTransaction(int empId, String address,
			PayrollDatabase database) {
		super(empId, database);
		this.address = address;
	}

	@Override
	protected PaymentMethod getMethod() {
		return new MailMethod(address);
	}

}
