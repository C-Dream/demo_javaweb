package com.hsbc.transactionImplementation;

import com.hsbc.abstracttransactions.ChangeMethodTransaction;
import com.hsbc.payrolldatabase.PayrollDatabase;
import com.hsbc.payrolldomain.PaymentMethod;
import com.hsbc.payrollimplementation.DirectDepositMethod;

public class ChangeDirectTransaction extends ChangeMethodTransaction {
	private final String bank;
	private final String account;

	public ChangeDirectTransaction(int empId, String bank, String account,
			PayrollDatabase database) {
		super(empId, database);
		this.bank = bank;
		this.account = account;
	}

	@Override
	protected PaymentMethod getMethod() {
		return new DirectDepositMethod(bank, account);
	}
}

