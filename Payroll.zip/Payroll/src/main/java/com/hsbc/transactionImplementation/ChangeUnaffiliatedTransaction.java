package com.hsbc.transactionImplementation;

import com.hsbc.abstracttransactions.ChangeAffiliationTransaction;
import com.hsbc.payrolldatabase.PayrollDatabase;
import com.hsbc.payrolldomain.Affiliation;
import com.hsbc.payrolldomain.Employee;
import com.hsbc.payrolldomain.NoAffiliation;
import com.hsbc.payrollimplementation.UnionAffiliation;

public class ChangeUnaffiliatedTransaction extends ChangeAffiliationTransaction {
	public ChangeUnaffiliatedTransaction(int empId, PayrollDatabase database) {
		super(empId, database);
	}

	@Override
	protected Affiliation getAffiliation() {
		return new NoAffiliation();
	}

	protected void RecordMembership(Employee e) {
		Affiliation affiliation = e.getAffiliation();
		if (affiliation instanceof UnionAffiliation) {
			UnionAffiliation unionAffiliation = (UnionAffiliation) affiliation;
			int memberId = unionAffiliation.getMemberId();
			database.RemoveUnionMember(memberId);
		}
	}

}