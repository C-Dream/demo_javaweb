package com.hsbc.transactionImplementation;

import com.hsbc.abstracttransactions.ChangeClassificationTransaction;
import com.hsbc.payrolldatabase.PayrollDatabase;
import com.hsbc.payrolldomain.PaymentClassification;
import com.hsbc.payrolldomain.PaymentSchedule;
import com.hsbc.payrollimplementation.MonthlySchedule;
import com.hsbc.payrollimplementation.SalariedClassification;

public class ChangeSalariedTransaction extends ChangeClassificationTransaction {
	private final double salary;

	public ChangeSalariedTransaction(int id, double salary,
			PayrollDatabase database) {
		super(id, database);
		this.salary = salary;
	}

	@Override
	protected PaymentClassification getClassification() {
		return new SalariedClassification(salary);
	}

	@Override
	protected PaymentSchedule getSchedule() {
		return new MonthlySchedule();
	}
}
