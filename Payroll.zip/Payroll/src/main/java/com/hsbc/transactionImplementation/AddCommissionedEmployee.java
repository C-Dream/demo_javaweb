package com.hsbc.transactionImplementation;

import com.hsbc.abstracttransactions.AddEmployeeTransaction;
import com.hsbc.payrolldatabase.PayrollDatabase;
import com.hsbc.payrolldomain.PaymentClassification;
import com.hsbc.payrolldomain.PaymentSchedule;
import com.hsbc.payrollimplementation.BiWeeklySchedule;
import com.hsbc.payrollimplementation.CommissionedClassification;

public class AddCommissionedEmployee extends AddEmployeeTransaction {
	private final double commissionRate;
	private final double baseRate;

	public AddCommissionedEmployee(int id, String name, String address,
			double baseRate, double commissionRate, PayrollDatabase database) {
		super(id, name, address, database);
		this.baseRate = baseRate;
		this.commissionRate = commissionRate;
	}

	protected PaymentClassification MakeClassification() {
		return new CommissionedClassification(baseRate, commissionRate);
	}

	protected PaymentSchedule MakeSchedule() {
		return new BiWeeklySchedule();
	}
}
