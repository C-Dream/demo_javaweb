package com.hsbc.transactionImplementation;

import com.hsbc.abstracttransactions.AddEmployeeTransaction;
import com.hsbc.payrolldatabase.PayrollDatabase;
import com.hsbc.payrolldomain.PaymentClassification;
import com.hsbc.payrolldomain.PaymentSchedule;
import com.hsbc.payrollimplementation.MonthlySchedule;
import com.hsbc.payrollimplementation.SalariedClassification;

public class AddSalariedEmployee extends AddEmployeeTransaction {
	private final double salary;

	public AddSalariedEmployee(int id, String name, String address,
			double salary, PayrollDatabase database) {
		super(id, name, address, database);
		this.salary = salary;
	}

	protected PaymentClassification MakeClassification() {
		return new SalariedClassification(salary);
	}

	protected PaymentSchedule MakeSchedule() {
		return new MonthlySchedule();
	}

}
