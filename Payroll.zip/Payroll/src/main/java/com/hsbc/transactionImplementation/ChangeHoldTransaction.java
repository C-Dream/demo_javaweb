package com.hsbc.transactionImplementation;

import com.hsbc.abstracttransactions.ChangeMethodTransaction;
import com.hsbc.payrolldatabase.PayrollDatabase;
import com.hsbc.payrolldomain.PaymentMethod;
import com.hsbc.payrollimplementation.HoldMethod;

public class ChangeHoldTransaction extends ChangeMethodTransaction {

	public ChangeHoldTransaction(int empId, PayrollDatabase database) {
		super(empId, database);
	}

	@Override
	protected PaymentMethod getMethod() {
		return new HoldMethod();
	}

}

