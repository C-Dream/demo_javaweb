package com.hsbc.transactionImplementation;

import com.hsbc.abstracttransactions.ChangeEmployeeTransaction;
import com.hsbc.payrolldatabase.PayrollDatabase;
import com.hsbc.payrolldomain.Employee;

public class ChangeNameTransaction extends ChangeEmployeeTransaction {
	private final String newName;

	public ChangeNameTransaction(int id, String newName,
			PayrollDatabase database) {
		super(id, database);
		this.newName = newName;
	}

	protected void Change(Employee e) {
		e.setName(newName);
	}

}
