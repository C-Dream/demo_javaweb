package com.hsbc.transactionImplementation;

import com.hsbc.abstracttransactions.ChangeEmployeeTransaction;
import com.hsbc.payrolldatabase.PayrollDatabase;
import com.hsbc.payrolldomain.Employee;

public class ChangeAddressTransaction extends ChangeEmployeeTransaction {
	private final String newAddress;

	public ChangeAddressTransaction(int id, String newAddress,
			PayrollDatabase database) {
		super(id, database);
		this.newAddress = newAddress;
	}

	protected void Change(Employee e) {
		e.setAddress(newAddress);
	}
}
