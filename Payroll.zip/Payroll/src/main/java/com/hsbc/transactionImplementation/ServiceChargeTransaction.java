package com.hsbc.transactionImplementation;

import java.util.Date;

import com.hsbc.payrolldatabase.PayrollDatabase;
import com.hsbc.payrolldomain.Employee;
import com.hsbc.payrollimplementation.ServiceCharge;
import com.hsbc.payrollimplementation.UnionAffiliation;
import com.hsbc.transactionapplication.Transaction;

public class ServiceChargeTransaction extends Transaction {

	private final int memberId;
	private final Date time;
	private final double charge;

	public ServiceChargeTransaction(int id, Date time, double charge,
			PayrollDatabase database) {
		super(database);
		this.memberId = id;
		this.time = time;
		this.charge = charge;
	}

	public void execute() throws Exception {
		Employee e = database.GetUnionMember(memberId);
		if (e != null) {
			UnionAffiliation ua = null;
			if (e.getAffiliation() instanceof UnionAffiliation)
				ua = (UnionAffiliation) e.getAffiliation();
			if (ua != null)
				ua.AddServiceCharge(new ServiceCharge(time, charge));
			else
				throw new Exception("Tries to add service charge to union"
						+ "member without a union affiliation");
		} else
			throw new Exception("No such union member.");
	}
}
