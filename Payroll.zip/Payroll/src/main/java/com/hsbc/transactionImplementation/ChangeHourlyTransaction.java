package com.hsbc.transactionImplementation;

import com.hsbc.abstracttransactions.ChangeClassificationTransaction;
import com.hsbc.payrolldatabase.PayrollDatabase;
import com.hsbc.payrolldomain.PaymentClassification;
import com.hsbc.payrolldomain.PaymentSchedule;
import com.hsbc.payrollimplementation.HourlyClassification;
import com.hsbc.payrollimplementation.WeeklySchedule;

public class ChangeHourlyTransaction extends ChangeClassificationTransaction {
	private final double hourlyRate;

	public ChangeHourlyTransaction(int id, double hourlyRate,
			PayrollDatabase database) {
		super(id, database);
		this.hourlyRate = hourlyRate;
	}

	@Override
	protected PaymentClassification getClassification() {
		return new HourlyClassification(hourlyRate);
	}

	@Override
	protected PaymentSchedule getSchedule() {
		return new WeeklySchedule();
	}
}
