package com.hsbc.abstracttransactions;

import com.hsbc.payrolldatabase.PayrollDatabase;
import com.hsbc.payrolldomain.Affiliation;
import com.hsbc.payrolldomain.Employee;

public abstract class ChangeAffiliationTransaction extends ChangeEmployeeTransaction {
	public ChangeAffiliationTransaction(int empId, PayrollDatabase database) {
		super(empId, database);
	}

	protected void Change(Employee e) {
		RecordMembership(e);
		Affiliation affiliation = getAffiliation();
		e.setAffiliation(affiliation);
	}

	protected abstract Affiliation getAffiliation();

	protected abstract void RecordMembership(Employee e);
}
