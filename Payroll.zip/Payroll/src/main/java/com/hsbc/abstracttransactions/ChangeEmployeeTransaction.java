package com.hsbc.abstracttransactions;

import com.hsbc.payrolldatabase.PayrollDatabase;
import com.hsbc.payrolldomain.Employee;
import com.hsbc.transactionapplication.Transaction;

public abstract class ChangeEmployeeTransaction extends Transaction {

	private final int empId;

	public ChangeEmployeeTransaction(int empId, PayrollDatabase database) {
		super(database);
		this.empId = empId;
	}

	public void execute() throws Exception {
		Employee e = database.GetEmployee(empId);
		if (e != null)
			Change(e);
		else
			throw new Exception("No such employee.");
	}

	protected abstract void Change(Employee e);
}
