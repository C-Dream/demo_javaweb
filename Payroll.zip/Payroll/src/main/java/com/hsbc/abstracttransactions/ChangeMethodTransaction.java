package com.hsbc.abstracttransactions;

import com.hsbc.payrolldatabase.PayrollDatabase;
import com.hsbc.payrolldomain.Employee;
import com.hsbc.payrolldomain.PaymentMethod;

public abstract class ChangeMethodTransaction extends ChangeEmployeeTransaction {

	public ChangeMethodTransaction(int empId, PayrollDatabase database) {
		super(empId, database);
	}

	protected void Change(Employee e) {
		PaymentMethod method = getMethod();
		e.setMethod(method);
	}

	protected abstract PaymentMethod getMethod();

}