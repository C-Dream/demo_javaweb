package com.hsbc.abstracttransactions;

import com.hsbc.payrolldatabase.PayrollDatabase;
import com.hsbc.payrolldomain.Employee;
import com.hsbc.payrolldomain.PaymentClassification;
import com.hsbc.payrolldomain.PaymentSchedule;

public abstract class ChangeClassificationTransaction extends ChangeEmployeeTransaction {
	public ChangeClassificationTransaction(int id, PayrollDatabase database) {
		super(id, database);
	}

	protected void Change(Employee e) {
		e.setClassification(getClassification());
		e.setSchedule(getSchedule());
	}

	protected abstract PaymentClassification getClassification();

	protected abstract PaymentSchedule getSchedule();
}
