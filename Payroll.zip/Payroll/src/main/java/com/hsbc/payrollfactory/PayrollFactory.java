package com.hsbc.payrollfactory;

public class PayrollFactory {

}
