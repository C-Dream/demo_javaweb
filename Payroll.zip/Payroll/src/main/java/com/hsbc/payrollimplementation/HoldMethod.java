package com.hsbc.payrollimplementation;

import com.hsbc.payrolldomain.Paycheck;
import com.hsbc.payrolldomain.PaymentMethod;

public class HoldMethod implements PaymentMethod {
	
	public void pay(Paycheck paycheck) {
		paycheck.setField("Disposition", "Hold");
	}

	public String ToString() {
		return "hold";
	}

}
