package com.hsbc.payrollimplementation;

public class PayrollFactoryImplementation {

}
