package com.hsbc.payrolldomain;

public interface PaymentMethod {
	void pay(Paycheck paycheck);
}
