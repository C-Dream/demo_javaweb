package com.hsbc.payrolldomain;

public class NoAffiliation implements Affiliation {

	public double calculateDeductions(Paycheck paycheck) {
		return 0;
	}
}

