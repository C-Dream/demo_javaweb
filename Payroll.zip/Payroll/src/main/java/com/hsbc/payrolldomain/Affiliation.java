package com.hsbc.payrolldomain;

public interface Affiliation {
	double calculateDeductions(Paycheck paycheck);
}
