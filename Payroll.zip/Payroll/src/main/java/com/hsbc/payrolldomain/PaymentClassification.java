package com.hsbc.payrolldomain;

public abstract class PaymentClassification {
	public abstract double calculatePay(Paycheck paycheck);
}
