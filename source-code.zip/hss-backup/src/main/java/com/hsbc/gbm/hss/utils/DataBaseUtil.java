package com.hsbc.gbm.hss.utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
 
public class DataBaseUtil {
	private static Connection conn = null;

	
	/** 
	 * 获取数据库连接
	 */
	public static Connection getConnection() {
		try {
			Class.forName(FileUtil.getValue("driver"));
			conn = DriverManager.getConnection(FileUtil.getValue("url"),FileUtil.getValue("user"),FileUtil.getValue("pass"));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return conn;
	}
	
	/**
	 * 关闭数据连接
	 * @param rs
	 * @param prep
	 * @param con
	 */
	public static void colseDB(ResultSet rs,PreparedStatement prep,Connection con){		 
    	if (rs != null) { 
		    try {  
		    	rs.close();
		    }
		    catch(SQLException s1){ 
		    	s1.printStackTrace();
		    }
		}
    	if (prep != null) { 
		    try {  
		    	prep.close();
		    }
		    catch(SQLException s2) { 
		    	s2.printStackTrace();
		    }
		} 
    	if (con != null) { 
		    try {  
		    	con.close();
		    }
		    catch(SQLException s3) { 
		    	s3.printStackTrace();
		    }
		} 
    }
  }
