package com.hsbc.gbm.hss.utils;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class FileUtil {
	private static Logger logger = LoggerFactory.getLogger(FileUtil.class);
	
	public static String getValue(String key) {
		Properties p = new Properties();
		try {
			InputStream in = FileUtil.class.getResourceAsStream("/mysqlconfig.properties");
			p.load(in);
			in.close();
			if (p.containsKey(key)) {
				return p.getProperty(key);
			}
		}
		catch (IOException ex) {
			logger.error(ex.getMessage(),ex);
		}		
		return null;
	}

}
