package com.hsbc.gbm.hss.service;

import java.util.List;

import com.hsbc.gbm.hss.dao.UserDao;
import com.hsbc.gbm.hss.dto.UserDto;

public class UserServiceImpl implements UserService{

	UserDao udao = new UserDao();
	
	@Override
	public List<UserDto> queryUser() {
		
		return udao.queryUser();
	}

	@Override
	public boolean deleteUser(String uId) {
		
		return udao.deleteUser(uId);
	}

	@Override
	public boolean updateUser(UserDto userDto) {
		
		return udao.updateUser(userDto);
	}

	@Override
	public boolean addUser(UserDto userDto) {
		
		return udao.addUser(userDto);
	}

}
