package com.hsbc.gbm.hss.service;

import java.util.List;

import com.hsbc.gbm.hss.dao.UserDao;
import com.hsbc.gbm.hss.dto.UserDto;

public class UserServiceImpl implements UserService{

	UserDao udao = new UserDao();
	
	public List<UserDto> queryUser() {
		
		return udao.queryUser();
	}

	public boolean deleteUser(String uId) {
		
		return udao.deleteUser(uId);
	}

	public boolean updateUser(UserDto userDto) {
		
		return udao.updateUser(userDto);
	}

	public boolean addUser(UserDto userDto) {
		
		return udao.addUser(userDto);
	}

}
