package com.hsbc.gbm.hss.dto;

public class UserDto {
	private String uId;
	private String uName;
	private int uAge;
	
	public String getuId() {
		return uId;
	}
	public void setuId(String uId) {
		this.uId = uId;
	}
	public String getuName() {
		return uName;
	}
	public void setuName(String uName) {
		this.uName = uName;
	}
	public int getuAge() {
		return uAge;
	}
	public void setuAge(int uAge) {
		this.uAge = uAge;
	}
	
	@Override
	public String toString() {
		return "UserDto [uId=" + uId + ", uName=" + uName + ", uAge=" + uAge + "]";
	}
}
