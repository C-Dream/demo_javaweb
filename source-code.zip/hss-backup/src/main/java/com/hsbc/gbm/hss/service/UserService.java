package com.hsbc.gbm.hss.service;

import java.util.List;

import com.hsbc.gbm.hss.dto.UserDto;

public interface UserService {
	
	public List<UserDto> queryUser();
	public boolean deleteUser(String uId);
	public boolean updateUser(UserDto userDto);
	public boolean addUser(UserDto userDto);
	
}
