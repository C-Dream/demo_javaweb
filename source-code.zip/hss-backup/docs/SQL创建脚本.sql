
/* 
 * 
 * CMD 创建数据库：create database demomaven;
 * 运行java脚本：com.hsbc.gbm.hss.utils.TestMySQL
 * 
 * 查数据：
 * use demomaven;
 * select * from users;
 * 
 */

drop table if exists users;
create table users(
	u_id varchar(64) not null,
	u_name varchar(128) null,
	u_age int(4),
	primary key (u_id)
);
commit;







