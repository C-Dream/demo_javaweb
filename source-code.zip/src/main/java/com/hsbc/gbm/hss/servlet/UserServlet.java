package com.hsbc.gbm.hss.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.hsbc.gbm.hss.service.UserService;
import com.hsbc.gbm.hss.service.UserServiceImpl;
import com.hsbc.gbm.hss.utils.InitTestData;

/**
 * 用户管理模块
 * @since 20200221
 * @version 1.0
 */
@SuppressWarnings("serial")
public class UserServlet extends HttpServlet { 	
	private static Logger logger = LoggerFactory.getLogger(UserServlet.class);
	
	UserService userService = new UserServiceImpl();
	
	/** 
	 * 方法重写(Overrides)：处理post请求
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException{
		this.doWeb(request,response); 
	}
	
	/** 
	 * 方法重写(Overrides)：处理get请求
	 */
	public void doGet(HttpServletRequest req, HttpServletResponse resp)throws ServletException, IOException{
		this.doWeb(req,resp); 
	}
	
	/**
	 * 网络请求的实际入口
	 * @param req http请求
	 * @param resp http响应
	 * @throws ServletException 异常类型
	 * @throws IOException 异常类型
	 */
	public void doWeb(HttpServletRequest req,HttpServletResponse resp)throws ServletException, IOException {
		req.setCharacterEncoding("UTF-8");		
		String action=(String)req.getParameter("forms");	
		if(null==action || action.replace("\\s", "").equals("") ){
			resp.setCharacterEncoding("UTF8");
			resp.sendRedirect(getSysPath(req));
			logger.error("请求不合法");
			return;
		}
		
		if(action.equalsIgnoreCase("userquery"))
			userQuery(req,resp) ; 
		if(action.equalsIgnoreCase("userdelete"))
			userDelete(req,resp) ; 
		if(action.equalsIgnoreCase("userupdate"))
			userUpdate(req,resp) ;
		if(action.equalsIgnoreCase("useradd")) 
			userAdd(req,resp);
		if(action.equalsIgnoreCase("userinit")) 
			userInit(req,resp);
	}
	
	
	private void userAdd(HttpServletRequest req, HttpServletResponse resp) {
		// TODO Auto-generated method stub
		
	}


	private void userUpdate(HttpServletRequest req, HttpServletResponse resp) {
		// TODO Auto-generated method stub
		
	}


	private void userDelete(HttpServletRequest req, HttpServletResponse resp) {
		try {
			if( null!=req.getParameter("u_id") ) {
				String u_id = (String)req.getParameter("u_id");				
				userService.deleteUser(u_id);
				logger.warn("操作成功，已删除用户（"+u_id+"）。");
			}else {
				logger.error("删除失败，参数不正确。");
			}			
			resp.setCharacterEncoding("UTF8");
			resp.sendRedirect(getSysPath(req));
			return;
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			
		}		
	}


	private void userQuery(HttpServletRequest req, HttpServletResponse resp) {
		// TODO Auto-generated method stub
		
	}

	private void userInit(HttpServletRequest req, HttpServletResponse resp) {
		try {
			if( null!=req.getParameter("u_id") ) {
				String u_id = (String)req.getParameter("u_id");				
				userService.deleteUser(u_id);
				logger.warn("操作成功，已删除用户（"+u_id+"）。");
			}else {
				logger.error("删除失败，参数不正确。");
			}	
			new InitTestData().testDb();
			resp.setCharacterEncoding("UTF8");
			resp.sendRedirect(getSysPath(req));
			return;
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			
		}		
	}

	/** 获取系统根路径<br>
	 * 用域名访问则获取域名，否则获取 IP。<br>
	 * http://域名/AppName<br>
	 * http://ip:port/AppName <br>
	*/
	public static String getSysPath(HttpServletRequest req){
		return  req.getScheme()+"://"+req.getServerName()+":"+req.getServerPort()+req.getContextPath();
	}
	

}