package com.hsbc.gbm.hss.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.hsbc.gbm.hss.dto.UserDto;
import com.hsbc.gbm.hss.utils.DataBaseUtil;

public class UserDao {
	
	public List<UserDto> queryUser() {
		Connection con = null;
		PreparedStatement prep=null; 
		ResultSet rs=null;
		List<UserDto> ls = new ArrayList<UserDto>();
		UserDto userDto  ; 
		try {
			con = DataBaseUtil.getConnection();
			String sql   = "select * from users";
			prep = con.prepareStatement( sql );
			rs = prep.executeQuery();
			while (null!=rs && rs.next()) { 
				userDto = new UserDto(); 
				userDto.setuAge(rs.getInt("u_age"));
				userDto.setuId(rs.getString("u_id"));
				userDto.setuName(rs.getString("u_name"));
				ls.add(userDto);
			} 
		} 
		catch (Exception e) { 
			e.printStackTrace();
		} finally {
			DataBaseUtil.colseDB(rs,prep,con);
    	}
		return ls;
	}

	public boolean deleteUser(String u_id) {
		Connection con = null;
		PreparedStatement prep=null; 
		ResultSet rs=null;
		boolean ok = true;
		try {
			con = DataBaseUtil.getConnection();
			String sql   = "delete from users where u_id=?";
			prep = con.prepareStatement( sql );
			prep.setString(1, u_id);
			prep.execute();
		} 
		catch (Exception e) { 
			ok = false;
			e.printStackTrace();
		} finally {
			DataBaseUtil.colseDB(rs,prep,con);
    	}
		return ok;
	}

	public boolean updateUser(UserDto userDto) {
		Connection con = null;
		PreparedStatement prep=null; 
		ResultSet rs=null;
		boolean ok = true;
		try {
			con = DataBaseUtil.getConnection();
			String sql   = "update users set u_name=?, u_age=? where u_id=?";
			prep = con.prepareStatement( sql );
			prep.setString(1, userDto.getuName());
			prep.setInt(2, userDto.getuAge());
			prep.setString(3, userDto.getuId());
			prep.execute();
		} 
		catch (Exception e) { 
			ok = false;
			e.printStackTrace();
		} finally {
			DataBaseUtil.colseDB(rs,prep,con);
    	}
		return ok;
	}

	/**
	 * 新增一个用户
	 * @param userDto
	 * @return
	 */
	public boolean addUser(UserDto userDto) {
		Connection con = null;
		PreparedStatement prep=null; 
		ResultSet rs=null;
		boolean ok = true;
		try {
			con = DataBaseUtil.getConnection();
			String sql   = "insert into users(u_id,u_name,u_age) values(?,?,?)";
			prep = con.prepareStatement( sql );
			prep.setString(1, userDto.getuName());
			prep.setInt(2, userDto.getuAge());
			prep.setString(3, userDto.getuId());
			prep.execute();
		} 
		catch (Exception e) { 
			ok = false;
			e.printStackTrace();
		} finally {
			DataBaseUtil.colseDB(rs,prep,con);
    	}
		return ok;
	}
}
