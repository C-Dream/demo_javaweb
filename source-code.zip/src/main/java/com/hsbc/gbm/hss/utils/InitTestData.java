package com.hsbc.gbm.hss.utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.hsbc.gbm.hss.utils.FileUtil;

public class InitTestData {
	private static Logger logger = LoggerFactory.getLogger(InitTestData.class);
	
//	private static String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver"; // com.mysql.jdbc.Driver
//	private static String DB_URL  = "jdbc:mysql://localhost:3306/demomaven?useSSL=false&serverTimezone=UTC";
//	private static String DB_USER = "root";
//	private static String DB_PASS = "root";

	public void testDb() {
		Connection conn = null;
		Statement stmt = null;
		ResultSet rs1 = null;
		try {
			Class.forName(FileUtil.getValue("driver"));
			conn = DriverManager.getConnection(FileUtil.getValue("url"),FileUtil.getValue("user"),FileUtil.getValue("pass"));
			stmt = conn.createStatement();
			
			String sqlDeleteTable = "drop table if exists users";
			stmt.execute(sqlDeleteTable);
			
			String sqlCreateTable = "create table users(" + 
					"	u_id varchar(64) not null," + 
					"	u_name varchar(128) null," + 
					"	u_age int(4)," + 
					"	primary key (u_id)" + 
					")";
			stmt.execute(sqlCreateTable);
			
			String sqlDeleteTableData = "delete from users where 1=1";
			stmt.execute(sqlDeleteTableData);
			
			String sqlData1 = "insert into users (u_id,u_name,u_age) values('1001','trista',11)";
			String sqlData2 = "insert into users (u_id,u_name,u_age) values('1002','hugo',22)";
			String sqlData3 = "insert into users (u_id,u_name,u_age) values('1003','xianzhi',33)";
			String sqlData4 = "insert into users (u_id,u_name,u_age) values('1004','test1',34)";
			String sqlData5 = "insert into users (u_id,u_name,u_age) values('1005','test2',35)";
			String sqlData6 = "insert into users (u_id,u_name,u_age) values('1006','jone',36)";
			String sqlData7 = "insert into users (u_id,u_name,u_age) values('1007','tom',37)";
			String sqlData8 = "insert into users (u_id,u_name,u_age) values('1008','jane',38)";
			String sqlData9 = "insert into users (u_id,u_name,u_age) values('1009','nice',39)";
			String sqlData0 = "insert into users (u_id,u_name,u_age) values('1010','aaaa',40)";
			stmt.addBatch(sqlData1);
			stmt.addBatch(sqlData2);
			stmt.addBatch(sqlData3);
			stmt.addBatch(sqlData4);
			stmt.addBatch(sqlData5);
			stmt.addBatch(sqlData6);
			stmt.addBatch(sqlData7);
			stmt.addBatch(sqlData8);
			stmt.addBatch(sqlData9);
			stmt.addBatch(sqlData0);
			stmt.executeBatch();
			
			String sqlQueryUser = "Select * from users where u_id is not null";
			rs1 = stmt.executeQuery(sqlQueryUser);
			StringBuilder sb = new StringBuilder(10000);
			while (rs1.next()) {
				sb.append("u_id="+rs1.getString("u_id"));
				sb.append(", u_name="+rs1.getString("u_name"));
				sb.append(", u_age="+rs1.getInt("u_age") +"\n");
			}
			logger.info(">> 查询结果如下：\n{}", sb.toString());
			
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if(null!=rs1) rs1.close();
				if(null!=stmt) stmt.close();
				if(null!=conn) conn.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		
	}
	
	public static void main(String[] args) {
		InitTestData tm = new InitTestData();
		tm.testDb();
	}

}
